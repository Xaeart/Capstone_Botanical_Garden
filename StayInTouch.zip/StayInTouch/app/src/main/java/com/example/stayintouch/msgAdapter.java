package com.example.stayintouch;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.Firebase;

import java.util.List;

/**
 * Created by abc on 4/26/2016.
 */
public class msgAdapter extends ArrayAdapter<Message> {


    List<Message> myMessage;
    Context myContext;
    int resource;
    ImageView storyImage;
    String sender;
    //DataHelper myHelper;

    public msgAdapter(Context context, int resource, List<Message> objects,String sender) {
        super(context, resource, objects);
        this.resource = resource;
        this.myMessage = objects;
        this.myContext = context;
        this.sender = sender;
        // myHelper = new DataHelper(getContext());

    }

    @Override
    public View getView(int position, View convertView, final ViewGroup parent) {

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) myContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(resource, parent, false);
        }

        convertView.setHorizontalFadingEdgeEnabled(true);
        final Message currentMessage = myMessage.get(position);

        if(currentMessage.getSender().equalsIgnoreCase(sender)){
            convertView.setBackgroundColor(Color.parseColor("#FFC0CB"));
        }
        else
        {
            convertView.setBackgroundColor(Color.parseColor("#ADD8E6"));
            ((ImageView)convertView.findViewById(R.id.deleteimg)).setVisibility(View.INVISIBLE);
        }

        ((TextView) convertView.findViewById(R.id.sender_Name)).setText(currentMessage.getSender() + "to "+ currentMessage.getReceiver());


        ((TextView) convertView.findViewById(R.id.message)).setText(currentMessage.getMessage_text());
        ((TextView) convertView.findViewById(R.id.message_date)).setText(currentMessage.getTime_stamp());
//        if(currentMessage.getMessage_read().equalsIgnoreCase("false"))
//        {
//          String uriRedDot = "@drawable/red";
//         int imageResource = convertView.getResources().getIdentifier(uriRedDot, null, myContext.getPackageName());
//        Drawable resource = convertView.getResources().getDrawable(imageResource);
//      //  redDot.setImageDrawable(resource);
//        }

        //delete message
        ((ImageView)convertView.findViewById(R.id.deleteimg)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Firebase itemRef =  new Firebase("https://stayin-touch.firebaseio.com/messages");
                //itemRef.child()
                // Query myMessage = itemRef.orderByKey().equalTo("sender")
                Toast.makeText(myContext,"Clicked", Toast.LENGTH_LONG).show();

            }
        });


        return convertView;
    }
}

