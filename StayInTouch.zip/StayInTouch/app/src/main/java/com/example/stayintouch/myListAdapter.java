package com.example.stayintouch;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by abc on 4/26/2016.
 */
public class myListAdapter extends ArrayAdapter<Contact> {


    List<Contact> myContact;
    Context myContext;
    int resource;
    ImageView storyImage;
    //DataHelper myHelper;

    public myListAdapter(Context context, int resource, List<Contact> objects) {
        super(context, resource, objects);
        this.resource = resource;
        this.myContact = objects;
        this.myContext = context;
        // myHelper = new DataHelper(getContext());

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) myContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(resource, parent, false);
        }

        final Contact currentContact = myContact.get(position);
        ((TextView) convertView.findViewById(R.id.fullName)).setText(currentContact.getFullName()); //FullName of the Sender

        //Send's Profile Picture
        byte[] decodedString = Base64.decode(currentContact.getPicture(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        ImageView profileImage = (ImageView) convertView.findViewById(R.id.profileImage);
        profileImage.setImageBitmap(decodedByte);

        //bluephone setup
        ImageView bluephone = (ImageView) convertView.findViewById(R.id.callImage);
        String uribluephone = "@drawable/phone";
        int imageResource1 = convertView.getResources().getIdentifier(uribluephone, null, myContext.getPackageName());
        Drawable resource1 = convertView.getResources().getDrawable(imageResource1);
        bluephone.setImageDrawable(resource1);
        bluephone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = currentContact.getPhoneNumber();
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + phone));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);// | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
                if (ActivityCompat.checkSelfPermission(myContext, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                myContext.startActivity(intent);
            }
        });

        return convertView;
    }
}