package com.example.stayintouch;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.BarDrawerToggle;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.AuthData;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.Query;
import com.firebase.client.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Launcher extends AppCompatActivity implements
        ViewContact.OnFragmentInteractionListener,
        Settings.OnFragmentInteractionListener,
        Messages.OnFragmentInteractionListener,
        Contacts.OnFragmentInteractionListener,
        Login.OnFragmentInteractionListener,
        Signup.OnFragmentInteractionListener,
        Conversation.OnFragmentInteractionListener
{


    Firebase mFirebaseRef;
    Firebase firebaseUserRef;
    Firebase mMessageRef;

    private static final int SELECT_PICTURE = 1;
    private String[] menuList = {"Contacts", "Conversations", "Archived", "Settings", "Logout", "Exit"};
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    private ArrayAdapter<String> mAdapter;
    ActionBarDrawerToggle mDrawerToggle;


    ArrayList<Contact> myContacts;
    Contact loggedUser;
    Contact contactClicked;
    ArrayList<Message> myMessages;
    ArrayList<Message> finalMessages;

    //ListView myMessageList;
   // msgAdapter adapter;
    String picPath = null;

    //Listners
    ValueEventListener msgListner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
        Firebase.setAndroidContext(Launcher.this);
        mFirebaseRef = new Firebase("https://stayin-touch.firebaseio.com/");
        mMessageRef = new Firebase("https://stayin-touch.firebaseio.com/messages");

        myMessages = new ArrayList<>();
        contactClicked = new Contact();
        myContacts = new ArrayList<>();
        finalMessages = new ArrayList<>();
        loggedUser = new Contact();
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        mDrawerList = (ListView) findViewById(R.id.left_drawer);
        mAdapter = new ArrayAdapter<String>(Launcher.this, android.R.layout.simple_list_item_1, menuList);
        //mDrawerList.setVisibility(View.INVISIBLE);

      //  myMessageList = (ListView) findViewById(R.id.messageList);

        if (mFirebaseRef.getAuth() != null) {
            Firebase mUserRef = new Firebase("https://stayin-touch.firebaseio.com/user");
            mUserRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot != null) {
                        for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                            Contact contacts = postSnapshot.getValue(Contact.class);
                            myContacts.add(contacts);
                        }
                        for (int i = 0; i < myContacts.size(); i++) {
                            if (myContacts.get(i).getEmail().equalsIgnoreCase(mFirebaseRef.getAuth().getProviderData().get("email").toString())) {
                                loggedUser = myContacts.get(i);

                                myContacts.remove(i);
                            }
                        }
                        LayoutInflater inflater = getLayoutInflater();
                        View listHeaderView = inflater.inflate(R.layout.navigation_header, null, false);
                        ImageView profileIMG = (ImageView) listHeaderView.findViewById(R.id.profileImage);
                        TextView profileName = (TextView) listHeaderView.findViewById(R.id.profileName);
                        profileName.setText(loggedUser.getFullName());
                        byte[] decodedString = Base64.decode(loggedUser.getPicture(), Base64.DEFAULT);
                        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                        profileIMG.setImageBitmap(decodedByte);
                        mDrawerList.addHeaderView(listHeaderView);
                        mDrawerList.setAdapter(mAdapter);
                        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                Log.d("InClick", "Listner");
                                //  Toast.makeText(getApplicationContext(),+":"+ position, Toast.LENGTH_SHORT).show();
                                String action = mDrawerList.getItemAtPosition(position).toString();
                                switch (action) {
                                    default:
                                    case "Contacts":

                                        getSupportFragmentManager().beginTransaction()
                                                .replace(R.id.drawer_layout, new Contacts(), "Contacts")
                                                .addToBackStack(null)
                                                .commit();

                                        break;
                                    case "Conversations":
                                        // fragment = new DefaultFragment();
                                        break;
                                    case "Archived":
                                        // fragment = new DefaultFragment();
                                        break;
                                    case "Settings":
                                        getSupportFragmentManager().beginTransaction()
                                                .replace(R.id.drawer_layout, new Settings(), "Settings")
                                                .addToBackStack(null)
                                                .commit();

                                        break;
                                    case "Logout":
                                        mFirebaseRef.unauth();
                                        getSupportFragmentManager().beginTransaction()
                                                .replace(R.id.drawer_layout, new Login(), "Settings")
                                                .addToBackStack(null)
                                                .commit();

                                        break;
                                    case "Exit":
                                        // fragment = new DefaultFragment();
                                        Launcher.this.finish();
                                        break;
                                }


                            }
                        });
                    }
                }

                @Override
                public void onCancelled(FirebaseError firebaseError) {

                }
            });
            //((ImageView)listHeaderView.findViewById(R.id.profileImage)).;
//            getSupportFragmentManager().beginTransaction()
//                    .add(R.id.drawer_layout, new Conversation(), "Conversations")
//                    .commit();
        } else {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.drawer_layout, new Login(), "login")
                    .commit();
        }

    }

    public void setUp() {
        //Navigation Hea

    }


    @Override
    public void doLogin(String username, String password) {

        mFirebaseRef.authWithPassword(username, password, new Firebase.AuthResultHandler() {
            @Override
            public void onAuthenticated(AuthData authData) {



                LayoutInflater inflater = getLayoutInflater();
                View listHeaderView = inflater.inflate(R.layout.navigation_header, null, false);
                ImageView profileIMG = (ImageView) listHeaderView.findViewById(R.id.profileImage);
                TextView profileName = (TextView) listHeaderView.findViewById(R.id.profileName);
                profileName.setText(loggedUser.getFullName());
                byte[] decodedString = Base64.decode(loggedUser.getPicture(), Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                profileIMG.setImageBitmap(decodedByte);
                mDrawerList.addHeaderView(listHeaderView);
                mDrawerList.setAdapter(mAdapter);
                mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Log.d("InClick", "Listner");
                        //  Toast.makeText(getApplicationContext(),+":"+ position, Toast.LENGTH_SHORT).show();
                        String action = mDrawerList.getItemAtPosition(position).toString();
                        switch (action) {
                            default:
                            case "Contacts":

                                getSupportFragmentManager().beginTransaction()
                                        .replace(R.id.drawer_layout, new Contacts(), "Contacts")
                                        .addToBackStack(null)
                                        .commit();

                                break;
                            case "Conversations":
                                // fragment = new DefaultFragment();
                                break;
                            case "Archived":
                                // fragment = new DefaultFragment();
                                break;
                            case "Settings":
                                getSupportFragmentManager().beginTransaction()
                                        .replace(R.id.drawer_layout, new Settings(), "Settings")
                                        .addToBackStack(null)
                                        .commit();

                                break;
                            case "Logout":
                                mFirebaseRef.unauth();
                                getSupportFragmentManager().beginTransaction()
                                        .replace(R.id.drawer_layout, new Login(), "Settings")
                                        .addToBackStack(null)
                                        .commit();

                                break;
                            case "Exit":
                                // fragment = new DefaultFragment();
                                Launcher.this.finish();
                                break;
                        }


                    }
                });


                getSupportFragmentManager().beginTransaction().replace(R.id.drawer_layout, new Conversation(), "Conversation")
                        .addToBackStack(null)
                        .commit();



            }

            @Override
            public void onAuthenticationError(FirebaseError firebaseError) {
                Toast.makeText(getApplicationContext(), firebaseError.getMessage().toString(), Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public void doSignup() {

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.drawer_layout, new Signup(), "Signup")
                .addToBackStack(null)
                .commit();

    }

    @Override
    public void doCreateAccount(final String username, final String email, final String phonenumber, final String password) {

        firebaseUserRef = new Firebase("https://stayin-touch.firebaseio.com/user/");


        firebaseUserRef.createUser(email, password, new Firebase.ValueResultHandler<Map<String, Object>>() {
            @Override
            public void onSuccess(Map<String, Object> result) {
                System.out.println("Successfully created user account with uid: " + result.get("uid"));

                Map<String, String> newUser = new HashMap<String, String>();
                Bitmap bmp = BitmapFactory.decodeResource(getResources(),
                        R.drawable.profile);//your image
                ByteArrayOutputStream bYtE = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.PNG, 100, bYtE);
                bmp.recycle();
                byte[] byteArray = bYtE.toByteArray();
                String imageFile = Base64.encodeToString(byteArray, Base64.DEFAULT);

                newUser.put("email", email);
                newUser.put("fullName", username.replaceAll(" ", "_"));
                newUser.put("password", password);
                newUser.put("phoneNumber", phonenumber);
                newUser.put("picture", imageFile);
                firebaseUserRef.child(username.replaceAll(" ", "_")).setValue(newUser);
                getSupportFragmentManager().beginTransaction().replace(R.id.drawer_layout, new Login(), "Login")
                        .addToBackStack(null)
                        .commit();

            }

            @Override
            public void onError(FirebaseError firebaseError) {
                Toast.makeText(getApplicationContext(), firebaseError.getMessage().toString(), Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void doCancelSignup() {

        getSupportFragmentManager().beginTransaction().replace(R.id.drawer_layout, new Login(), "Login")
                .addToBackStack(null)
                .commit();

    }


    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public void loadContactList(View contactListView) {

        final ListView myList = (ListView) findViewById(R.id.contactList);
        final myListAdapter adapter = new myListAdapter(getApplicationContext(), R.layout.row_item, myContacts);
        myList.setAdapter(adapter);
        adapter.setNotifyOnChange(true);

        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Log.d("Contact CLicked:", myContacts.get(position).toString());
                contactClicked = myContacts.get(position);
                adapter.notifyDataSetChanged();
                getSupportFragmentManager().beginTransaction().replace(R.id.drawer_layout, new Messages(), "Messages")
                        .addToBackStack(null)
                        .commit();
            }
        });

        myList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                contactClicked = myContacts.get(position);

                getSupportFragmentManager().beginTransaction().replace(R.id.drawer_layout, new ViewContact(), "ViewContact")
                        .addToBackStack(null)
                        .commit();


                return true;
            }
        });

    }

    @Override
    public void listMessages() {

 Toast.makeText(getApplicationContext(),contactClicked.getFullName(),Toast.LENGTH_LONG).show();
        msgListner = this.mMessageRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (dataSnapshot != null) {
                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        Message message = postSnapshot.getValue(Message.class);
                        Log.d("Message", message.toString());

                        if (message.getSender().equalsIgnoreCase(loggedUser.getFullName()) && message.getReceiver().equalsIgnoreCase(contactClicked.getFullName())
                                || message.getReceiver().equalsIgnoreCase(loggedUser.getFullName()) && message.getSender().equalsIgnoreCase(contactClicked.getFullName()))

                            if (!myMessages.contains(message)) {
                                myMessages.add(message);
                            }
                    }

                    for (int i = 0; i < myMessages.size(); i++) {
                        Log.d("Selected Messages: ", myMessages.get(i).toString());

                    }

                    final ListView  myMessageList = (ListView) findViewById(R.id.messageList);
                    Log.d("List count", myMessageList.getChildCount() + "");

//                     myList = (ListView) findViewById(R.id.contactList);
//                    myListAdapter adapter = new myListAdapter(getApplicationContext(), R.layout.row_item, myContacts);
//                    myList.setAdapter(adapter);
//                    adapter.setNotifyOnChange(true);


                    msgAdapter adapter = new msgAdapter(getApplicationContext(), R.layout.message_item, myMessages, loggedUser.getFullName());

                    myMessageList.setAdapter(adapter);

                    adapter.setNotifyOnChange(true);
                }
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
    }

    @Override
    public void sendMessage() {

        // EditText messageText = (EditText)findViewById(R.id.messageBox);
        Firebase mMessageRef = new Firebase("https://stayin-touch.firebaseio.com/messages");
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy HH:mm:ss a");
        String timestamp = sdf.format(new Date());
        Map<String, String> newMessage = new HashMap<String, String>();
        newMessage.put("time_stamp", timestamp);
        newMessage.put("message_read", "false");
        newMessage.put("message_text", ((EditText) findViewById(R.id.messageBox)).getText().toString());
        newMessage.put("receiver", contactClicked.getFullName());
        newMessage.put("sender", loggedUser.getFullName());
        mFirebaseRef.getRoot().removeEventListener(msgListner);
        mMessageRef.push().setValue(newMessage);

        Firebase mConversationRef = new Firebase("https://stayin-touch.firebaseio.com/conversations");
        Map<String, String> newConversation = new HashMap<String, String>();
        newConversation.put("deletedBy", "false");
        newConversation.put("IsArchived_by_participant1", "false");
        newConversation.put("IsArchived_by_participant2", "false");
        newConversation.put("participant1", contactClicked.getFullName());
        newConversation.put("participant2", loggedUser.getFullName());

        mConversationRef.push().setValue(newConversation);

                ((EditText) findViewById(R.id.messageBox)).setText("");
        //adapter.notifyDataSetChanged();

       // adapter.clear();


    }

    @Override
    public void editProfile() {

        Log.d("Logged User", loggedUser.toString());

        ((TextView) findViewById(R.id.profile_Name)).setText(loggedUser.getFullName());

        ((EditText) findViewById(R.id.username)).setText(loggedUser.getFullName());
        ((EditText) findViewById(R.id.email)).setText(loggedUser.getEmail());
        ((EditText) findViewById(R.id.phonenumber)).setText(loggedUser.getPhoneNumber());
        ((EditText) findViewById(R.id.password)).setText(loggedUser.getPassword());

        ImageView profileImage = (ImageView) findViewById(R.id.profile_Image);
        byte[] decodedString = Base64.decode(loggedUser.getPicture(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        Log.d("Decode", "=" + decodedByte + "");
        profileImage.setImageBitmap(decodedByte);

        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent gintent = new Intent();
                    gintent.setType("image/*");
                    gintent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(
                            Intent.createChooser(gintent, "Select Picture"),
                            SELECT_PICTURE);
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(),
                            e.getMessage(),
                            Toast.LENGTH_LONG).show();
                    Log.e(e.getClass().getName(), e.getMessage(), e);
                }
            }
        });


        //Update button Click handler
        ((Button) findViewById(R.id.update)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String printemail = ((EditText) findViewById(R.id.email)).getText().toString();
                String printpassword = ((EditText) findViewById(R.id.password)).getText().toString();
                Log.d("Email and Password", printemail + " and " + printpassword);
                Log.d("Email and Password", mFirebaseRef.getAuth().getProviderData().get("email").toString());
                Log.d("Email and Password", mFirebaseRef.getAuth().getProviderData().toString());
                if (!mFirebaseRef.getAuth().getProviderData().get("email").toString().equals(printemail)) //|| !mFirebaseRef.getAuth().getProviderData().get("password").toString().equals(printpassword))
                {
                    mFirebaseRef.changeEmail(loggedUser.getEmail(), loggedUser.getPassword(), ((EditText) findViewById(R.id.email)).getText().toString(), null);
                    mFirebaseRef.changePassword(loggedUser.getEmail(), loggedUser.getPassword(), ((EditText) findViewById(R.id.password)).getText().toString(), null);
                }

                //mFirebaseRef = new Firebase("https://stayin-touch.firebaseio.com/user");//dataconnection
                String email = loggedUser.getEmail();  //mFirebaseRef.getAuth().getProviderData().get("email").toString();//loggedin User email
                String user = email.substring(0, email.indexOf('@'));//key for the user


                //  Bitmap bmp = BitmapFactory.decodeResource(getResources(), picPath);//your image
                String imageFile = null;
                if (picPath != null) {
                    Bitmap bmp = BitmapFactory.decodeFile(picPath);
                    ByteArrayOutputStream bYtE = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, bYtE);
                    bmp.recycle();
                    byte[] byteArray = bYtE.toByteArray();
                    imageFile = Base64.encodeToString(byteArray, Base64.DEFAULT);
                } else {
                    imageFile = loggedUser.getPicture();
                }


                Firebase mupdateRef = new Firebase("https://stayin-touch.firebaseio.com/user");
                Contact updateContact = new Contact(((EditText) findViewById(R.id.email)).getText().toString(), ((TextView) findViewById(R.id.username)).getText().toString()
                        , ((EditText) findViewById(R.id.password)).getText().toString(), ((EditText) findViewById(R.id.phonenumber)).getText().toString(),
                        imageFile);
                mupdateRef.child(user).setValue(updateContact, new Firebase.CompletionListener() {
                    @Override
                    public void onComplete(FirebaseError firebaseError, Firebase firebase) {
                        doLogin(((EditText) findViewById(R.id.email)).getText().toString(), ((EditText) findViewById(R.id.password)).getText().toString());
                        Toast.makeText(getApplicationContext(), "Changes Saved Successfully", Toast.LENGTH_LONG).show();
                        getSupportFragmentManager().beginTransaction()
                                .replace(R.id.drawer_layout, new Login(), "login")
                                .addToBackStack(null)
                                .commit();

                    }
                });
            }
        });


//        (findViewById(R.id.cancel)).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });


    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Uri selectedImageUri = null;

        //Log.d("Path","mypath="+filePath );
        if (resultCode == Activity.RESULT_OK) {
            selectedImageUri = data.getData();
            Log.d("URI", "=" + selectedImageUri);
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                ((ImageView) findViewById(R.id.profile_Image)).setImageBitmap(bitmap);
                getPath(data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
            //
        }
    }

    public void getPath(Uri uri) {

        String[] projection = {MediaStore.Images.Media.DATA};
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        picPath = cursor.getString(column_index);
        //return cursror.getString(column_index);
    }

    @Override
    public void onStop() {
        super.onStop();
        // mFirebaseRef.getRoot().removeEventListener(msgListner);
//        mMessageRef.getRoot().removeEventListener(msgListner);
        //adapter.clear();


    }

    @Override
    public void viewContactDeails() {


        mFirebaseRef = new Firebase("https://stayin-touch.firebaseio.com/user");

        ((TextView) findViewById(R.id.userName)).setText(contactClicked.getFullName());
        ((TextView) findViewById(R.id.user_name)).setText(contactClicked.getFullName());
        ((TextView) findViewById(R.id.email)).setText(contactClicked.getEmail());
        ((TextView) findViewById(R.id.phonenumber)).setText(contactClicked.getPhoneNumber());

        ImageView profileImage = (ImageView) findViewById(R.id.userImage);
        byte[] decodedString = Base64.decode(contactClicked.getPicture(), Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        profileImage.setImageBitmap(decodedByte);

//        if (getIntent() != null) {
//            currentContact = (Contacts) getIntent().getSerializableExtra("CURRENTCONTACT");
//            Log.d("currentContact:", currentContact.toString());
//
//            Query ref = mFirebaseRef.orderByChild("email").equalTo(currentContact.getEmail());
//            ref.addValueEventListener(new ValueEventListener() {
//                @Override
//                public void onDataChange(DataSnapshot dataSnapshot) {
//                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
//                        Contacts contact = postSnapshot.getValue(Contacts.class);
//
//
//                        //((EditText) findViewById(R.id.password)).setText(contact.getPassword());
//                    }
//
//                }
//
//                @Override
//                public void onCancelled(FirebaseError firebaseError) {
//
//                }
//            });


        }





    }
